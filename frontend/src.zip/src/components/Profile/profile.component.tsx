import * as React from 'react';

function Profile() {
    
	return (
		<div>
			Welcome to Profile
		</div>
	);
}

export default Profile;