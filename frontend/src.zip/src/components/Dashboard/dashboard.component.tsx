import React from 'react';

function Dashboard() {
    return (
        <div>
            Welcome to Dashboard!
        </div>
    );
}

export default Dashboard;
