import React from 'react';
import DirectorDetails from './directorDetails';

export default class Director extends React.Component {
  render() {
    return (
        <div className="dora-container">
          <DirectorDetails/>
        </div>
      );
  }
}
